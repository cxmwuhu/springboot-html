package com.jesper.model;

import lombok.Data;

@Data
public class Express {

    private int id;
    private String time;
    private String context;
    private String location;
}
