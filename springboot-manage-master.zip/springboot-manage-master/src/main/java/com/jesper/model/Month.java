package com.jesper.model;

import lombok.Data;

@Data
public class Month {
    private int Jan;
    private int Feb;
    private int Mar;
    private int Apr;
    private int May;
    private int Jun;
    private int Jul;
    private int Aug;
    private int Sep;
    private int Oct;
    private int Nov;
    private int Dec;

}
